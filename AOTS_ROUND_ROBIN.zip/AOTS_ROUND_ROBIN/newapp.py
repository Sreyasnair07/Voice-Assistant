import asyncio
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional, Set
from dataclasses import dataclass, asdict
from enum import Enum

import httpx
from fastapi import FastAPI, Request, Form, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

# Feature Flags
class FeatureFlags:
    TEAMS_NOTIFICATIONS = True
    AUTO_ASSIGNMENT = True
    WEBSOCKET_UPDATES = True
    ROUND_ROBIN_ASSIGNMENT = True
    TICKET_LOCKING = True
    PERIODIC_FETCH = True
    FETCH_INTERVAL_SECONDS = 15
    MAX_TICKETS_PER_FETCH = 100
    WEBSOCKET_HEARTBEAT = 30

# Data Models
@dataclass
class Agent:
    attuid: str
    name: str
    is_online: bool = False
    tickets_assigned: int = 0
    last_activity: Optional[datetime] = None

@dataclass
class Ticket:
    ticket_num: str
    problem_abstract: str
    assigned_to: Optional[str] = None
    created_at: datetime = None
    assigned_at: Optional[datetime] = None
    status: str = "unassigned"

# Application State
class TicketSystem:
    def __init__(self):
        self.agents: Dict[str, Agent] = {}
        self.tickets: Dict[str, Ticket] = {}
        self.websocket_clients: Set[WebSocket] = set()
        self.assignment_lock = asyncio.Lock()
        self.last_assigned_index = -1
        self.access_token = '862491f1-0504-4b9d-92f7-2960f3a0b24e'
        self.teams_webhook_url = None
        self._initialize_agents()
    def _initialize_agents(self):
        agents_data = [
            {"attuid": "ds670v", "name": "Dipanu Saha"},
            {"attuid": "sx474j", "name": "Shamnath Shajahan"}, 
            {"attuid": "kc3046", "name": "Sibi Chakravarthy"},
            {"attuid": "rt5327", "name": "Rajesh Tellatakula"},
            {"attuid": "hs5829", "name": "Hitesh V Sanil"},
            {"attuid": "Ax5064", "name": "Abdul Gaffur Shaik"},
            {"attuid": "sd6808", "name": "Sahithi Darapureddy"},
            {"attuid": "jw0197", "name": "Tejashree Jarugu"},
            {"attuid": "sr8445", "name": "Sushmetha Rs"}
        ]
        for agent_data in agents_data:
            agent = Agent(**agent_data)
            self.agents[agent.attuid] = agent
    def get_online_agents(self) -> List[Agent]:
        return [agent for agent in self.agents.values() if agent.is_online]
    def get_unassigned_tickets(self) -> List[Ticket]:
        return [ticket for ticket in self.tickets.values() if not ticket.assigned_to]

system = TicketSystem()

# Logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('ticket_system.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Teams Integration
class TeamsNotifier:
    @staticmethod
    async def send_notification(webhook_url: str, message: str, title: str = "Ticket System"):
        if not FeatureFlags.TEAMS_NOTIFICATIONS or not webhook_url:
            return False
        payload = {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": "0078D4",
            "summary": title,
            "sections": [{
                "activityTitle": title,
                "activitySubtitle": f"AT&T AOTS - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                "activityImage": "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c7/AT%26T_logo_2016.svg/200px-AT%26T_logo_2016.svg.png",
                "facts": [{
                    "name": "Message",
                    "value": message
                }],
                "markdown": True
            }]
        }
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(webhook_url, json=payload)
                response.raise_for_status()
                logger.info(f"Teams notification sent successfully: {title}")
                return True
        except Exception as e:
            logger.error(f"Failed to send Teams notification: {e}")
            return False

# Core Business Logic
class TicketAssigner:
    @staticmethod
    async def fetch_tickets_from_aots() -> List[dict]:
        if not FeatureFlags.PERIODIC_FETCH:
            return []
        url = f"https://aotswl.it.att.com:14205/AOTSTicketService/rest/ticket/ticket-list?access_token={system.access_token}"
        body = {
            "queryString": "(( 'Managing Org' in  (\"CALLCTRTEC\" ,\"CONS-MRKTS\")) AND ( 'Active Org' in (\"CALLCTRTEC-INF\",\"CONS-MRKTS-CARE\")) AND ( 'Work Queue' in (\"HD-ETALK ADMIN SUPT ANLST\", \"CORAL APPLICATION\") ) AND ( 'Client ID' = \"ATT_IT\" ) AND ( 'Ticket State' = \"Active\"OR 'Ticket State' = \"Queued\" OR 'Ticket State' = \"AutoOpen\" OR 'Ticket State' = \"AutoFix\" ) AND not ( 'Assigned-to'  in (\"rt5327\",\"sr8445\",\"sx474j\",\"ds670v\",\"st6808\",\"hs5829\",\"ax5064\",\"jw0197\",\"kc3046\")) AND ('Owner ID' =\"Unassigned\")) AND ( ('Client ID' = \"ATT_IT\" ))  AND  'Problem Abstract' <> \"TIER 2_RECORDING DOWNLOAD REQUEST\" ",
            "clientTimeZoneOffset": -330,
        }
        try:
            async with httpx.AsyncClient(verify=False, timeout=30.0) as client:
                response = await client.post(url, json=body)
                response.raise_for_status()
                data = response.json()
                return data[:FeatureFlags.MAX_TICKETS_PER_FETCH] if data else []
        except Exception as e:
            logger.error(f"Error fetching tickets from AOTS: {e}")
            return []
    @staticmethod 
    async def lock_ticket_on_aots(ticket_num: str, attuid: str) -> bool:
        if not FeatureFlags.TICKET_LOCKING:
            return True
        url = f"https://aotswl.it.att.com:14205/AOTSTicketService/rest/ticket/lock/{ticket_num}/{attuid}?access_token={system.access_token}"
        try:
            async with httpx.AsyncClient(verify=False, timeout=10.0) as client:
                response = await client.put(url)
                response.raise_for_status()
                logger.info(f"Ticket {ticket_num} locked for {attuid}")
                return True
        except Exception as e:
            logger.error(f"Failed to lock ticket {ticket_num}: {e}")
            return False
    @staticmethod
    async def assign_tickets():
        if not FeatureFlags.AUTO_ASSIGNMENT:
            return "Auto-assignment disabled"
        async with system.assignment_lock:
            online_agents = system.get_online_agents()
            unassigned_tickets = system.get_unassigned_tickets()
            if not online_agents:
                return "No online agents available"
            if not unassigned_tickets:
                return "No unassigned tickets"
            assigned_count = 0
            for ticket in unassigned_tickets:
                if FeatureFlags.ROUND_ROBIN_ASSIGNMENT:
                    system.last_assigned_index = (system.last_assigned_index + 1) % len(online_agents)
                    selected_agent = online_agents[system.last_assigned_index]
                else:
                    selected_agent = min(online_agents, key=lambda a: a.tickets_assigned)
                # Lock ticket on AOTS
                if await TicketAssigner.lock_ticket_on_aots(ticket.ticket_num, selected_agent.attuid):
                    ticket.assigned_to = selected_agent.attuid
                    ticket.assigned_at = datetime.now()
                    ticket.status = "assigned"
                    selected_agent.tickets_assigned += 1
                    assigned_count += 1
                    if system.teams_webhook_url:
                        message = f"🎫 Ticket #{ticket.ticket_num} assigned to {selected_agent.name}\n📝 {ticket.problem_abstract[:100]}..."
                        await TeamsNotifier.send_notification(
                            system.teams_webhook_url, 
                            message,
                            "Ticket Assigned"
                        )
            await broadcast_updates()
            return f"Assigned {assigned_count} tickets"

# WebSocket Management
async def broadcast_updates():
    if not FeatureFlags.WEBSOCKET_UPDATES:
        return
    data = {
        "online_agents": [asdict(agent) for agent in system.get_online_agents()],
        "unassigned_tickets": [asdict(ticket) for ticket in system.get_unassigned_tickets()],
        "assigned_tickets": [asdict(ticket) for ticket in list(system.tickets.values())[-10:] if ticket.assigned_to],
        "timestamp": datetime.now().isoformat()
    }
    message = json.dumps(data, default=str)
    disconnected = []
    for client in system.websocket_clients:
        try:
            await client.send_text(message)
        except Exception:
            disconnected.append(client)
    for client in disconnected:
        system.websocket_clients.discard(client)

# FastAPI App
app = FastAPI(title="AT&T AOTS Ticket Assignment", version="2.0.0")
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request, message: str = None):
    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "agents": list(system.agents.values()),
        "online_agents": system.get_online_agents(),
        "unassigned_tickets": system.get_unassigned_tickets(),
        "assigned_tickets": [t for t in system.tickets.values() if t.assigned_to][-10:],
        "message": message,
        "feature_flags": FeatureFlags
    })

@app.post("/agent/login")
async def agent_login(request: Request, attuid: str = Form(...)):
    agent = system.agents.get(attuid)
    if not agent:
        return RedirectResponse(url="/?message=Agent%20not%20found", status_code=302)
    agent.is_online = True
    agent.last_activity = datetime.now()
    if system.teams_webhook_url:
        await TeamsNotifier.send_notification(
            system.teams_webhook_url,
            f"🟢 {agent.name} ({attuid}) is now ONLINE",
            "Agent Login"
        )
    await broadcast_updates()
    return RedirectResponse(url="/?message=Agent%20logged%20in", status_code=302)

@app.post("/agent/logout")
async def agent_logout(request: Request, attuid: str = Form(...)):
    agent = system.agents.get(attuid)
    if not agent:
        return RedirectResponse(url="/?message=Agent%20not%20found", status_code=302)
    agent.is_online = False
    if system.teams_webhook_url:
        await TeamsNotifier.send_notification(
            system.teams_webhook_url,
            f"🔴 {agent.name} ({attuid}) is now OFFLINE",
            "Agent Logout"
        )
    await broadcast_updates()
    return RedirectResponse(url="/?message=Agent%20logged%20out", status_code=302)

@app.get("/api/fetch-assign")
async def manual_fetch_assign():
    try:
        new_tickets = await TicketAssigner.fetch_tickets_from_aots()
        added_count = 0
        for ticket_data in new_tickets:
            if ticket_data["ticketNum"] not in system.tickets:
                ticket = Ticket(
                    ticket_num=ticket_data["ticketNum"],
                    problem_abstract=ticket_data.get("problemAbstract", "No description"),
                    created_at=datetime.now()
                )
                system.tickets[ticket.ticket_num] = ticket
                added_count += 1
        assign_result = await TicketAssigner.assign_tickets()
        return {
            "success": True, 
            "message": f"Added {added_count} new tickets. {assign_result}"
        }
    except Exception as e:
        logger.error(f"Error in manual fetch/assign: {e}")
        return {"success": False, "message": str(e)}

@app.post("/api/teams-webhook")
async def set_teams_webhook(request: Request, webhook_url: str = Form(...)):
    system.teams_webhook_url = webhook_url
    return RedirectResponse(url="/?message=Teams%20webhook%20configured", status_code=302)

@app.websocket("/ws/updates")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    system.websocket_clients.add(websocket)
    logger.info("WebSocket client connected")
    try:
        while True:
            await asyncio.sleep(FeatureFlags.WEBSOCKET_HEARTBEAT)
            await websocket.ping()
    except WebSocketDisconnect:
        system.websocket_clients.discard(websocket)
        logger.info("WebSocket client disconnected")

# Background Task
async def periodic_fetch_and_assign():
    while True:
        try:
            if FeatureFlags.PERIODIC_FETCH:
                new_tickets = await TicketAssigner.fetch_tickets_from_aots()
                for ticket_data in new_tickets:
                    if ticket_data["ticketNum"] not in system.tickets:
                        ticket = Ticket(
                            ticket_num=ticket_data["ticketNum"],
                            problem_abstract=ticket_data.get("problemAbstract", "No description"),
                            created_at=datetime.now()
                        )
                        system.tickets[ticket.ticket_num] = ticket
                await TicketAssigner.assign_tickets()
        except Exception as e:
            logger.error(f"Error in periodic task: {e}")
            if system.teams_webhook_url:
                await TeamsNotifier.send_notification(
                    system.teams_webhook_url,
                    f"System Error: {str(e)}",
                    "System Alert"
                )
        await asyncio.sleep(FeatureFlags.FETCH_INTERVAL_SECONDS)

@app.on_event("startup")
async def startup_event():
    logger.info("Starting AT&T AOTS Ticket Assignment System v2.0")
    asyncio.create_task(periodic_fetch_and_assign())
    if system.teams_webhook_url:
        await TeamsNotifier.send_notification(
            system.teams_webhook_url,
            "Ticket Assignment System is now ONLINE",
            "System Started"
        )

@app.on_event("shutdown")
async def shutdown_event():
    logger.info("Shutting down Ticket Assignment System")
    if system.teams_webhook_url:
        await TeamsNotifier.send_notification(
            system.teams_webhook_url,
            "Ticket Assignment System is going OFFLINE",
            "System Shutdown"
        )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
