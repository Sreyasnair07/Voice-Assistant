import asyncio
import json
import logging
import socket
from typing import Dict, List, Optional, Set, Tuple, Any

from fastapi import FastAPI, Request, Form, BackgroundTasks, WebSocket, WebSocketDisconnect, HTTPException, Body
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
import httpx

# === Constants and Configurations ===

TEMPLATES_DIR = "templates"
LOG_FILE = "app_activity.log"
# ACCESS_TOKEN removed. Now dynamic.
AOTS_API_URL_TEMPLATE = "https://aotswl.it.att.com:14205/AOTSTicketService/rest/ticket/ticket-list?access_token={}"
AOTS_API_BODY = {
    "queryString": "(( 'Managing Org' in  (\"CALLCTRTEC\" ,\"CONS-MRKTS\")) AND ( 'Active Org' in (\"CALLCTRTEC-INF\",\"CONS-MRKTS-CARE\")) AND ( 'Work Queue' in (\"HD-ETALK ADMIN SUPT ANLST\", \"CORAL APPLICATION\") ) AND ( 'Client ID' = \"ATT_IT\" ) AND ( 'Ticket State' = \"Active\"OR 'Ticket State' = \"Queued\" OR 'Ticket State' = \"AutoOpen\" OR 'Ticket State' = \"AutoFix\" ) AND not ( 'Assigned-to'  in (\"rt5327\",\"sr8445\",\"sx474j\",\"ds670v\",\"st6808\",\"hs5829\",\"ax5064\",\"jw0197\",\"kc3046\")) AND ('Owner ID' =\"Unassigned\")) AND ( ('Client ID' = \"ATT_IT\" ))  AND  'Problem Abstract' <> \"TIER 2_RECORDING DOWNLOAD REQUEST\" ",
    "clientTimeZoneOffset": -330,
}

# === Logging Setup ===

def setup_logger(name: str, log_file: str) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    handler = logging.FileHandler(log_file)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger

logger = setup_logger("ticket_assignment_app", LOG_FILE)

# === FastAPI App and Templates ===

app = FastAPI()
templates = Jinja2Templates(directory=TEMPLATES_DIR)

# Add CORS Middleware to allow UserScript to post token
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict this to specific domains if possible, but for UserScript * is often needed or specific domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# === Data Stores ===

all_employees: List[Dict[str, str]] = [
    {"attuid": "ds670v", "name": "Dipanu Saha"},
    {"attuid": "sx474j", "name": "Shamnath Shajahan"},
    {"attuid": "kc3046", "name": "Sibi Chakravarthy"},
    {"attuid": "rt5327", "name": "Rajesh Tellatakula"},
    {"attuid": "hs5829", "name": "Hitesh V Sanil"},
    {"attuid": "Ax5064", "name": "Abdul Gaffur Shaik"},
    {"attuid": "sd6808", "name": "Sahithi Darapureddy"},
    {"attuid": "jw0197", "name": "Tejashree Jarugu"},
    {"attuid": "sr8445", "name": "Sushmetha Rs"}
]

tickets: List[Dict[str, Any]] = []
online_employees: Set[str] = set()
clients: Set[WebSocket] = set()

last_assigned_index: int = -1
lock = asyncio.Lock()

# Global variable to store the dynamic token
current_access_token: Optional[str] = None

# === Helper Functions ===

def get_employee(attuid: str) -> Optional[Dict[str, str]]:
    """Return employee dict by attuid."""
    return next((e for e in all_employees if e["attuid"] == attuid), None)

def get_client_ip_and_system_info(request: Request) -> Tuple[str, str, str]:
    """Extract client IP and system info from request."""
    x_forwarded_for = request.headers.get('X-Forwarded-For')
    client_ip = x_forwarded_for.split(',')[0].strip() if x_forwarded_for else request.client.host
    hostname = socket.gethostname()
    try:
        system_ip = socket.gethostbyname(hostname)
    except socket.gaierror:
        system_ip = 'Unable to get IP'
    return client_ip, hostname, system_ip

async def fetch_tickets_from_aots() -> List[Dict[str, Any]]:
    """Fetch tickets from AOTS API."""
    global current_access_token
    if not current_access_token:
        logger.warning("No access token available. Skipping fetch.")
        return []

    url = AOTS_API_URL_TEMPLATE.format(current_access_token)
    async with httpx.AsyncClient(verify=False) as client:
        try:
            response = await client.post(url, json=AOTS_API_BODY)
            if response.status_code == 401:
                logger.error("Access token expired or invalid.")
                current_access_token = None # Reset invalid token
                return []
            response.raise_for_status()
            data = response.json()
            return data if data else []
        except (httpx.HTTPError, json.JSONDecodeError) as e:
            logger.error(f"Error fetching tickets from API: {e}")
            return []

async def lock_ticket_on_aots(ticket_num: str, attuid: str) -> bool:
    """Lock ticket on AOTS system."""
    global current_access_token
    if not current_access_token:
        logger.warning("No access token available. Cannot lock ticket.")
        return False

    url = f"https://aotswl.it.att.com:14205/AOTSTicketService/rest/ticket/lock/{ticket_num}/{attuid}?access_token={current_access_token}"
    async with httpx.AsyncClient(verify=False) as client:
        try:
            response = await client.put(url)
            if response.status_code == 401:
                logger.error("Access token expired or invalid during lock.")
                current_access_token = None
                return False
            response.raise_for_status()
            logger.info(f"Locked ticket {ticket_num} for agent {attuid}")
            return True
        except httpx.HTTPStatusError as exc:
            logger.error(f"Failed to lock ticket {ticket_num} for {attuid}: {exc.response.status_code} {exc.response.text}")
            return False
        except Exception as e:
            logger.error(f"Error locking ticket {ticket_num} for {attuid}: {e}")
            return False

async def broadcast_tickets_update() -> None:
    """Send latest ticket/agent info to all connected websocket clients."""
    assigned_tickets = [t for t in tickets if t["assigned_to"] is not None]
    last_10_assigned = assigned_tickets[-10:]
    unassigned_tickets = [t for t in tickets if t["assigned_to"] is None]
    online_list = [get_employee(eid) for eid in online_employees]

    data = {
        "online_agents": online_list,
        "unassigned_tickets": unassigned_tickets,
        "assigned_tickets": last_10_assigned,
        "token_status": "Active" if current_access_token else "Missing"
    }
    message = json.dumps(data)

    disconnected = set()
    for client in clients:
        try:
            await client.send_text(message)
        except Exception:
            disconnected.add(client)
    clients.difference_update(disconnected)

async def update_tickets_and_assign() -> str:
    """Fetch tickets and assign to online agents in round robin."""
    global last_assigned_index
    
    if not current_access_token:
        return "Skipping fetch: No access token."

    logger.info("Fetching tickets from AOTS API...")
    new_tickets_data = await fetch_tickets_from_aots()
    logger.info(f"Fetched {len(new_tickets_data)} tickets from AOTS API.")

    known_ticket_nums = {t["ticketNum"] for t in tickets}
    new_added = 0
    for t in new_tickets_data:
        if t["ticketNum"] not in known_ticket_nums:
            tickets.append({
                "ticketNum": t["ticketNum"],
                "problemAbstract": t.get("problemAbstract", "No description"),
                "assigned_to": None,
                "raw": t,
            })
            new_added += 1
    if new_added > 0:
        logger.info(f"Added {new_added} new tickets to local storage.")

    async with lock:
        online_list = [e for e in all_employees if e["attuid"] in online_employees]
        if not online_list:
            # logger.warning("No online agents available to assign tickets.")
            # Don't spam logs if no agents
            pass
        else:
            unassigned = [t for t in tickets if t["assigned_to"] is None]
            assigned_count = 0
            for ticket in unassigned:
                last_assigned_index = (last_assigned_index + 1) % len(online_list)
                assigned_emp = online_list[last_assigned_index]

                success = await lock_ticket_on_aots(ticket["ticketNum"], assigned_emp["attuid"])
                if success:
                    ticket["assigned_to"] = assigned_emp["attuid"]
                    assigned_count += 1
                    logger.info(f"Assigned ticket {ticket['ticketNum']} to {assigned_emp['name']} ({assigned_emp['attuid']})")
                else:
                    logger.warning(f"Could not assign ticket {ticket['ticketNum']} to {assigned_emp['name']} ({assigned_emp['attuid']})")

    await broadcast_tickets_update()
    return f"Assigned {new_added} new tickets."

# === API Endpoints ===

@app.get("/", response_class=HTMLResponse)
async def home(request: Request, message: Optional[str] = None, selected_attuid: Optional[str] = None):
    assigned_tickets = [t for t in tickets if t["assigned_to"] is not None]
    last_10_assigned = assigned_tickets[-10:]
    return templates.TemplateResponse("index.html", {
        "request": request,
        "employees": all_employees,
        "online_employees": [get_employee(eid) for eid in online_employees],
        "tickets": tickets,
        "unassigned_tickets": [t for t in tickets if t["assigned_to"] is None],
        "assigned_tickets": last_10_assigned,
        "message": message,
        "selected_attuid": selected_attuid,
        "token_status": "Active" if current_access_token else "Missing"
    })

@app.post("/login", response_class=HTMLResponse)
async def login(request: Request, attuid: str = Form(...)):
    employee = get_employee(attuid)
    ip = get_client_ip_and_system_info(request)
    if not employee:
        message = f"Agent ID {attuid} not found."
        logger.warning(f"Failed login attempt for unknown agent {attuid} from IP {ip}")
    else:
        online_employees.add(attuid)
        message = f"Agent {employee['name']} ({attuid}) is now ONLINE."
        logger.info(f"Agent {employee['name']} ({attuid}) logged IN from IP {ip}")
    await broadcast_tickets_update()
    return await home(request, message=message, selected_attuid=attuid)

@app.post("/logout", response_class=HTMLResponse)
async def logout(request: Request, attuid: str = Form(...)):
    employee = get_employee(attuid)
    ip = get_client_ip_and_system_info(request)
    if attuid in online_employees:
        online_employees.remove(attuid)
        message = f"Agent {employee['name']} ({attuid}) is now OFFLINE."
        logger.info(f"Agent {employee['name']} ({attuid}) logged OUT from IP {ip}")
    else:
        message = f"Agent {employee['name']} ({attuid}) was not online."
        logger.warning(f"Agent {employee['name']} ({attuid}) attempted logout but was not online. IP {ip}")
    await broadcast_tickets_update()
    return await home(request, message=message, selected_attuid=attuid)

@app.post("/update-token")
async def update_token(token_data: Dict[str, str] = Body(...)):
    """Endpoint to receive the Bearer token dynamically."""
    global current_access_token
    token = token_data.get("token")
    if not token:
        raise HTTPException(status_code=400, detail="Token is required")
    
    current_access_token = token
    logger.info("Access token updated dynamically.")
    await broadcast_tickets_update()
    return {"message": "Token updated successfully", "status": "Active"}

@app.get("/fetch-and-assign")
async def fetch_and_assign(background_tasks: BackgroundTasks):
    background_tasks.add_task(update_tickets_and_assign)
    return {"message": "Fetching tickets from AOTS and assigning in background"}

@app.get("/fetch-and-assign-now", response_class=HTMLResponse)
async def fetch_and_assign_now(request: Request):
    message = await update_tickets_and_assign()
    return await home(request, message=message)

@app.websocket("/ws/tickets")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    clients.add(websocket)
    # Send initial state
    await broadcast_tickets_update()
    logger.info("New websocket client connected.")
    try:
        while True:
            await asyncio.sleep(10)  # Keep connection alive
    except WebSocketDisconnect:
        clients.remove(websocket)
        logger.info("Websocket client disconnected.")

@app.on_event("startup")
async def start_periodic_fetch_assign():
    async def periodic_fetch_assign():
        while True:
            try:
                msg = await update_tickets_and_assign()
                # logger.info(f"[Periodic] {msg}") # Reduce noise
            except Exception as e:
                logger.error(f"[Periodic] Error during fetch and assign: {e}", exc_info=True)
            await asyncio.sleep(15)

    asyncio.create_task(periodic_fetch_assign())