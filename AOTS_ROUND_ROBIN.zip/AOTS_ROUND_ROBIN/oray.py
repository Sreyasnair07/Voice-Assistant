import cx_oracle
 
# Replace with your Oracle connection details
username = 'm14852'
password = 'C24P#1709necr%mi'
dsn = 'p7cgp1d1.az.3pc.att.com:1521/p7cgp1d1'
 
# Example query
query = "SELECT 1"
 
try:
    # Establish connection
    connection = cx_oracle.connect(username,password,dsn)
    cursor = connection.cursor()
    cursor.execute(query)
 
    # Fetch and print results
    for row in cursor.fetchall():
        print(row)
 
except cx_oracle.DatabaseError as e:
    print("Database error:", e)
finally:
    if cursor:
        cursor.close()
    if connection:
        connection.close()


        