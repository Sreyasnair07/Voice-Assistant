// ==UserScript==
// @name         AOTS Token Extractor
// @namespace    http://tampermonkey.net/
// @version      2025-11-22
// @description  Extracts AOTS token and sends to local app
// @author       Iron Man
// @match        https://aotswl.it.att.com:14205/AOTSWeb/app/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=mozilla.org
// @grant        GM_xmlhttpRequest
// ==/UserScript==
alert('AOTS Token Extractor loaded!');
(function () {
    'use strict';

    const TARGET_APP_URL = 'http://localhost:8000/update-token'; // Change if your app runs elsewhere
    const TOKEN_API_URL = 'https://aotswl.it.att.com:14205/AOTSWeb/app/rest/user';

    console.log("AOTS Token Extractor: Script loaded.");

    function fetchAndSendToken() {
        console.log("AOTS Token Extractor: Attempting to fetch token...");

        // Use standard fetch if possible, or GM_xmlhttpRequest if CORS is an issue (though we added CORS to our app)
        // Since we are on aotswl.it.att.com, fetching from same origin should be fine.
        fetch(TOKEN_API_URL)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                // Try to find the token in the response
                // Updated: Use 'aotsRestAccesstoken' from API response
                let extractedToken = data.aotsRestAccesstoken;

                if (extractedToken) {
                    sendTokenToApp(extractedToken);
                } else {
                    console.warn("AOTS Token Extractor: Could not find 'aotsRestAccesstoken' in response.", data);
                    // Try to look in sessionStorage or localStorage as backup
                    let storageToken = sessionStorage.getItem('aotsRestAccesstoken') || localStorage.getItem('aotsRestAccesstoken');
                    if (storageToken) {
                        console.log("AOTS Token Extractor: Found token in storage.");
                        sendTokenToApp(storageToken);
                    }
                }
            })
            .catch(e => {
                console.error("AOTS Token Extractor: Error fetching user info", e);
            });
    }

    function sendTokenToApp(token) {
        console.log("AOTS Token Extractor: Sending token to app...", token.substring(0, 10) + "...");

        GM_xmlhttpRequest({
            method: "POST",
            url: TARGET_APP_URL,
            headers: {
                "Content-Type": "application/json"
            },
            data: JSON.stringify({ token: token }),
            onload: function (response) {
                if (response.status === 200) {
                    console.log("AOTS Token Extractor: Token successfully sent to app.");
                    // Optional: Show a notification on the page
                    let div = document.createElement('div');
                    div.style.position = 'fixed';
                    div.style.bottom = '10px';
                    div.style.right = '10px';
                    div.style.backgroundColor = '#d4edda';
                    div.style.color = '#155724';
                    div.style.padding = '10px';
                    div.style.borderRadius = '5px';
                    div.style.zIndex = '9999';
                    div.textContent = 'AOTS Token Synced!';
                    document.body.appendChild(div);
                    setTimeout(() => div.remove(), 3000);
                } else {
                    console.error("AOTS Token Extractor: Failed to send token to app.", response.responseText);
                }
            },
            onerror: function (err) {
                console.error("AOTS Token Extractor: Error sending token to app.", err);
            }
        });
    }

    // Run on load
    window.addEventListener('load', () => {
        setTimeout(fetchAndSendToken, 3000); // Wait a bit for app to initialize
    });

    // Optional: Add a button to manually trigger
    window.addEventListener('load', () => {
        let btn = document.createElement('button');
        btn.textContent = "Sync Token";
        btn.style.position = 'fixed';
        btn.style.bottom = '10px';
        btn.style.left = '10px';
        btn.style.zIndex = '9999';
        btn.onclick = fetchAndSendToken;
        document.body.appendChild(btn);
    });

})();
