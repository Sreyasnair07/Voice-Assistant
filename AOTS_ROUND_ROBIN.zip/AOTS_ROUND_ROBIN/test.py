import logging
import httpx
from fastapi import FastAPI
from fastapi.responses import JSONResponse

logger = logging.getLogger("ticket_assignment_app")
logging.basicConfig(level=logging.INFO)

app = FastAPI()

async def fetch_access_token():
    user_api_url = "https://aotswl.it.att.com:14205/AOTSWeb/app/rest/user"
    async with httpx.AsyncClient(verify=False) as client:
        try:
            response = await client.get(user_api_url)
            logger.info(f"Response status: {response.status_code}")
            logger.info(f"Response content: {response.text!r}")

            response.raise_for_status()

            if not response.text.strip():
                logger.error("Empty response body received from user API.")
                return None

            data = response.json()
            token = data.get("aotsRestAccesstoken")
            if token:
                logger.info("Access token fetched successfully")
                return token
            else:
                logger.error("Access token not found in user API response.")
                return None

        except httpx.HTTPStatusError as http_err:
            logger.error(f"HTTP error occurred: {http_err}")
            return None
        except ValueError as json_err:
            logger.error(f"JSON decoding failed: {json_err}")
            logger.error(f"Response text was: {response.text!r}")
            return None
        except Exception as e:
            logger.error(f"Failed to fetch access token: {e}")
            return None

@app.get("/get-token")
async def get_token():
    token = await fetch_access_token()
    if token:
        return JSONResponse(content={"access_token": token})
    else:
        return JSONResponse(status_code=500, content={"error": "Failed to fetch access token"})
    

import asyncio

async def main():
    token = await fetch_access_token()
    print("Token:", token)

if __name__ == "__main__":
    asyncio.run(main())